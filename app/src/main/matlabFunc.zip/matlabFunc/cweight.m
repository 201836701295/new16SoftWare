function [p,ff,Lp] = cweight(x)
[p,ff] = octbank(x,44100);
weight=[-0.8 -0.2 0  0  0 -0.2 -0.8 -3.0];
LA=zeros(1,8);
LA=10.^(0.1*(p+weight));
Lp=10*log10(sum(LA));
p = single(p);
ff = single(ff);
Lp = single(Lp);
end

