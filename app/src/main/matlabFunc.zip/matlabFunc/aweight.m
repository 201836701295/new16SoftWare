function [p,ff,Lp] = aweight(x)
[p,ff] = octbank(x,44100);
weight=[-26.2 -16.1 -8.6  -3.2  0 1.2 1.0 -1.1];
LA=zeros(1,8);
LA=10.^(0.1*(p+weight));
Lp=10*log10(sum(LA));
p = single(p);
ff = single(ff);
Lp = single(Lp);
end

