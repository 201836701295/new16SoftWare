function [p,ff,Lp] = zweight(x)
[p,ff] = octbank(x,44100);
LA=zeros(1,8);
LA=10.^(0.1*p);
Lp=10*log10(sum(LA));
p = single(p);
ff = single(ff);
Lp = single(Lp);
end

