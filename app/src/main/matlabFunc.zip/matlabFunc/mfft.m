function [F] = mfft(X,N)
F = fft(X,N);
end

