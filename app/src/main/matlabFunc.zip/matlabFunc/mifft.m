function [X] = mifft(F,N)
X = ifft(F,N);
end